const express = require("express");
const User = require("../models/user");
const authenticateToken = require("../middleware/authMiddleware");

const router = express.Router();

// Lấy thông tin User Profile
router.get("/profile", authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select("-password"); // Loại bỏ password
        if (!user) {
            return res.status(404).json({ message: "Người dùng không tồn tại!" });
        }
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
});

module.exports = router;
