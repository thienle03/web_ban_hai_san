document.addEventListener("DOMContentLoaded", loadCart);

function loadCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartTable = document.getElementById("cart-items");
    let totalPrice = 0;

    cartTable.innerHTML = ""; // Clear the table before adding new items

    cart.forEach((item, index) => {
        let itemTotal = item.price * item.quantity;
        totalPrice += itemTotal;

        let row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.name}</td>
            <td><img src="${item.image}" alt="${item.name}" width="50"></td>
            <td>${item.price.toLocaleString()} VND</td>
            <td>
                <input type="number" min="1" value="${item.quantity}" onchange="updateQuantity(${index}, this.value)">
            </td>
            <td>${itemTotal.toLocaleString()} VND</td>
            <td><button onclick="removeItem(${index})">🗑️</button></td>
        `;
        cartTable.appendChild(row);
    });

    document.getElementById("cart-total").innerText = totalPrice.toLocaleString();
}

function updateQuantity(index, newQuantity) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart[index].quantity = parseInt(newQuantity);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart(); // Refresh cart
}

function removeItem(index) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart(); // Refresh cart
}

function clearCart() {
    localStorage.removeItem("cart");
    loadCart(); // Refresh cart
}

function redirectToCheckout() {
    window.location.href = "checkout.html";
}
