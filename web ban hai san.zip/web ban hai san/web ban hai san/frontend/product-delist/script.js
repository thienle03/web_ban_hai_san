document.getElementById("add-to-cart").addEventListener("click", () => {
    alert("Sản phẩm đã được thêm vào giỏ hàng!");
});
