document.addEventListener("DOMContentLoaded", function () {
    loadCartItems();
});

// Load sản phẩm đã chọn vào danh sách
function loadCartItems() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let orderList = document.getElementById("order-items");
    let totalPrice = 0;

    orderList.innerHTML = "";
    cart.forEach((item, index) => {
        let li = document.createElement("li");
        li.innerHTML = `${item.name} x${item.quantity} <span>${item.price * item.quantity} VND</span>`;
        orderList.appendChild(li);
        totalPrice += item.price * item.quantity;
    });

    document.getElementById("total-price").innerText = totalPrice.toLocaleString();
}

// Xác nhận đơn hàng
function confirmOrder() {
    let name = document.getElementById("name").value;
    let address = document.getElementById("address").value;
    let phone = document.getElementById("phone").value;
    let paymentMethod = document.querySelector('input[name="payment"]:checked').value;

    if (!name || !address || !phone) {
        alert("Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    let orderDetails = {
        name: name,
        address: address,
        phone: phone,
        paymentMethod: paymentMethod,
        items: JSON.parse(localStorage.getItem("cart")) || [],
        total: document.getElementById("total-price").innerText
    };

    localStorage.removeItem("cart");
    alert("Đơn hàng của bạn đã được đặt thành công!");
    window.location.href = "success.html"; // Chuyển hướng đến trang xác nhận đơn hàng
}
