document.addEventListener("DOMContentLoaded", function () {
    loadOrderHistory();
});

// Load danh sách đơn hàng từ localStorage
function loadOrderHistory() {
    let orders = JSON.parse(localStorage.getItem("orders")) || [];
    let orderList = document.getElementById("order-history-list");

    orderList.innerHTML = "";
    orders.forEach((order, index) => {
        let li = document.createElement("li");
        li.classList.add("order-item");
        li.innerHTML = `
            <span>📦 Đơn hàng #${index + 1} - ${order.total} VND</span>
            <button onclick="toggleDetails(${index})">Chi Tiết</button>
            <div class="order-details" id="details-${index}">
                <p><strong>Họ và Tên:</strong> ${order.name}</p>
                <p><strong>Địa Chỉ:</strong> ${order.address}</p>
                <p><strong>Số Điện Thoại:</strong> ${order.phone}</p>
                <p><strong>Phương Thức Thanh Toán:</strong> ${order.paymentMethod}</p>
                <p><strong>Sản Phẩm:</strong></p>
                <ul>${order.items.map(item => `<li>${item.name} x${item.quantity} - ${item.price * item.quantity} VND</li>`).join("")}</ul>
            </div>
        `;
        orderList.appendChild(li);
    });
}

// Hiển thị chi tiết đơn hàng
function toggleDetails(index) {
    let details = document.getElementById(`details-${index}`);
    details.style.display = details.style.display === "block" ? "none" : "block";
}
