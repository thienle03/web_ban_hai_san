const container = document.getElementById("container");
const registerBtn = document.getElementById("register");
const loginBtn = document.getElementById("login");

registerBtn.addEventListener("click", () => {
  container.classList.add("active");
});

loginBtn.addEventListener("click", () => {
  container.classList.remove("active");
});
// Xử lý đăng nhập
document.querySelector(".sign-in form").addEventListener("submit", (e) => {
  e.preventDefault(); // Ngăn chặn reload trang

  const email = document.querySelector(".sign-in input[type='email']").value;
  const password = document.querySelector(".sign-in input[type='password']").value;

  // Kiểm tra tài khoản (có thể thay bằng API kiểm tra từ backend)
  if (email === "admin@gmail.com" && password === "123456") {
      localStorage.setItem("isLoggedIn", "true"); // Lưu trạng thái đăng nhập
      window.location.href = "../Page/index.html"; // Chuyển đến trang chính
  } else {
      alert("Email hoặc mật khẩu không đúng!");
  }
});